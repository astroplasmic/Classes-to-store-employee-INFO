#include <iostream>
#include <string>
using namespace std;

// Base Class: Employee
class Employee
{
protected:
    string name;
    int id;
    double salary;

public:
    Employee(string n, int i, double s)
    {
        name = n;
        id = i;
        salary = s;
        cout << "Employee Constructor Called for: " << name << endl;
    }

    virtual ~Employee()
    {
        cout << "Employee Destructor Called for: " << name << endl;
    }

    virtual void displayInfo()
    {
        cout << "Employee Info:\n";
        cout << "Name: " << name << "\nID: " << id
            << "\nSalary: $" << salary << endl;
    }
};


// Derived Class: Manager
class Manager : public Employee
{
private:
    string department;

public:
    Manager(string n, int i, double s, string d)
        : Employee(n, i, s)
    {
        department = d;
        cout << "Manager Constructor Called for: " << name << endl;
    }

    ~Manager()
    {
        cout << "Manager Destructor Called for: " << name << endl;
    }

    void displayInfo() override
    {
        cout << "Manager Info:\n";
        cout << "Name: " << name << "\nID: " << id
            << "\nSalary: $" << salary
            << "\nDepartment: " << department << endl;
    }
};


// Derived Class: Engineer
class Engineer : public Employee
{
private:
    string specialty;

public:
    Engineer(string n, int i, double s, string sp)
        : Employee(n, i, s)
    {
        specialty = sp;
        cout << "Engineer Constructor Called for: " << name << endl;
    }

    ~Engineer()
    {
        cout << "Engineer Destructor Called for: " << name << endl;
    }

    void displayInfo() override
    {
        cout << "Engineer Info:\n";
        cout << "Name: " << name << "\nID: " << id
            << "\nSalary: $" << salary
            << "\nSpecialty: " << specialty << endl;
    }
};

// Derived Class: Intern
class Intern : public Employee
{
private:
    string school;

public:
    Intern(string n, int i, double s, string sc)
        : Employee(n, i, s)
    {
        school = sc;
        cout << "Intern Constructor Called for: " << name << endl;
    }

    ~Intern()
    {
        cout << "Intern Destructor Called for: " << name << endl;
    }

    void displayInfo() override
    {
        cout << "Intern Info:\n";
        cout << "Name: " << name << "\nID: " << id
            << "\nSalary: $" << salary
            << "\nSchool: " << school << endl;
    }
};


// Main Function
int main()
{
    // Array of base class pointers
    Employee* employees[3];

    // Creating objects dynamically
    employees[0] = new Manager("Alex", 101, 30000, "Finance");
    employees[1] = new Engineer("Ben", 202, 100000, "Software");
    employees[2] = new Intern("Chis", 303, 50000, "State University");

    cout << "\n\n--- Displaying Employee Information (Polymorphism) ---\n";
    for (int i = 0; i < 3; i++)
    {
        employees[0]->displayInfo();
        cout << endl;
    }

    // Clean up to show destructor order
    cout << "\n\n--- Destroying Objects ---\n";
    for (int i = 0; i < 3; i++)
    {
        delete employees[i];
    }

    return 0;
}
